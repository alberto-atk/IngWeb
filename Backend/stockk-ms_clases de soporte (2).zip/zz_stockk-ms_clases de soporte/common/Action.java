
package fs.stockk.ms.common;

/**
 *
 * @author fserna
 */
public enum Action {
    UNDEFINED,
    SELL_HIGHER_THAN,
    SELL_LOWER_THAN,
    BUY_LOWER_THAN,
    AUTO_AI
}
